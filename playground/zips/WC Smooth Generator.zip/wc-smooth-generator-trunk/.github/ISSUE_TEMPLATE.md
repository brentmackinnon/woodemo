<!-- This form is for other issue types specific to WooCommerce Smooth Generator. This is not a support portal. -->

**Prerequisites (mark completed items with an [x]):**
- [ ] I have checked that my issue type is not listed here https://github.com/woocommerce/wc-smooth-generator/issues/new/choose
- [ ] My issue is not a security issue, bug report, or enhancement (Please use the link above if it is).

**Issue Description:**
